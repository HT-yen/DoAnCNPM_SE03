package constant;

public class define {
     
	  public final static int ROW_COUNT=5;
	  public final static int ROW_COUNT_NEWS=6;
	  public final static int ROW_COUNT_BaiVietMoi=3;
	 
	 
	  
}
